KotoBot Website (React + Tailwind + Vite)
------------------------------------------------
Tips:
1. Replace YOUR_CLIENT_ID in src files with your Discord Application Client ID to make the invite buttons work.
2. To run locally:
   - npm install
   - npm run dev
3. To deploy to Vercel: push to GitHub and import the repo in Vercel.
